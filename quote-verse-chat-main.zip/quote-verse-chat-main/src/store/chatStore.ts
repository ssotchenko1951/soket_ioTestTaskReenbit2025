
import { create } from 'zustand';
import { immer } from 'zustand/middleware/immer';
import { ChatStore, Chat, Message } from '../types';

export const useChatStore = create<ChatStore>()(
  immer((set, get) => ({
    chats: [],
    messages: {},
    currentChatId: null,
    isConnected: false,
    isLoading: false,
    searchQuery: '',

    setChats: (chats) =>
      set((state) => {
        state.chats = chats;
        console.log('Chats updated in store:', chats.length);
      }),

    addChat: (chat) =>
      set((state) => {
        // Check if chat already exists
        const existingIndex = state.chats.findIndex(c => c.id === chat.id);
        if (existingIndex === -1) {
          state.chats.unshift(chat);
          console.log('New chat added to store:', chat.id);
        } else {
          // Update existing chat
          state.chats[existingIndex] = { ...state.chats[existingIndex], ...chat };
          console.log('Existing chat updated in store:', chat.id);
        }
      }),

    updateChat: (chatId, updates) =>
      set((state) => {
        const chatIndex = state.chats.findIndex((c) => c.id === chatId);
        if (chatIndex !== -1) {
          Object.assign(state.chats[chatIndex], updates);
          console.log('Chat updated in store:', chatId, updates);
        }
      }),

    deleteChat: (chatId) =>
      set((state) => {
        state.chats = state.chats.filter((c) => c.id !== chatId);
        delete state.messages[chatId];
        if (state.currentChatId === chatId) {
          state.currentChatId = null;
        }
        console.log('Chat deleted from store:', chatId);
      }),

    setCurrentChat: (chatId) =>
      set((state) => {
        state.currentChatId = chatId;
        console.log('Current chat set:', chatId);
        
        // Mark messages as read when chat is opened
        if (chatId && state.messages[chatId]) {
          state.messages[chatId].forEach(message => {
            if (!message.isRead && message.senderId !== 'current-user') {
              message.isRead = true;
            }
          });
          
          // Reset unread count
          const chatIndex = state.chats.findIndex(c => c.id === chatId);
          if (chatIndex !== -1) {
            state.chats[chatIndex].unreadCount = 0;
          }
        }
      }),

    addMessage: (message) =>
      set((state) => {
        if (!state.messages[message.chatId]) {
          state.messages[message.chatId] = [];
        }
        
        // Check if message already exists to avoid duplicates
        const existingMessage = state.messages[message.chatId].find(m => m.id === message.id);
        if (!existingMessage) {
          state.messages[message.chatId].push(message);
          console.log('New message added to store:', message.id, 'in chat:', message.chatId);
        } else {
          console.log('Message already exists in store:', message.id);
          return;
        }
        
        // Update chat's last message and move to top
        const chatIndex = state.chats.findIndex((c) => c.id === message.chatId);
        if (chatIndex !== -1) {
          const chat = state.chats[chatIndex];
          chat.lastMessage = message;
          chat.lastMessageTime = message.timestamp;
          
          // Increment unread count for messages from others
          if (message.senderId !== 'current-user' && state.currentChatId !== message.chatId) {
            chat.unreadCount = (chat.unreadCount || 0) + 1;
          }
          
          // Move chat to top of list
          state.chats.splice(chatIndex, 1);
          state.chats.unshift(chat);
        }
      }),

    updateMessage: (messageId, updates) =>
      set((state) => {
        Object.values(state.messages).forEach((chatMessages) => {
          const messageIndex = chatMessages.findIndex((m) => m.id === messageId);
          if (messageIndex !== -1) {
            Object.assign(chatMessages[messageIndex], updates);
            console.log('Message updated in store:', messageId, updates);
          }
        });
      }),

    setMessages: (chatId, messages) =>
      set((state) => {
        state.messages[chatId] = messages;
        console.log('Messages set for chat:', chatId, messages.length);
      }),

    setConnected: (connected) =>
      set((state) => {
        state.isConnected = connected;
        console.log('Connection status updated:', connected);
      }),

    setLoading: (loading) =>
      set((state) => {
        state.isLoading = loading;
      }),

    setSearchQuery: (query) =>
      set((state) => {
        state.searchQuery = query;
      }),

    getFilteredChats: () => {
      const { chats, searchQuery } = get();
      if (!searchQuery.trim()) return chats;
      
      const query = searchQuery.toLowerCase();
      return chats.filter(
        (chat) =>
          chat.firstName.toLowerCase().includes(query) ||
          chat.lastName.toLowerCase().includes(query) ||
          chat.lastMessage?.content.toLowerCase().includes(query)
      );
    },
  }))
);
