
import React, { useState, Suspense, useEffect } from 'react';
import { useChatStore } from '../store/chatStore';
import { useSocketChat } from '../hooks/useSocketChat';
import { useChats } from '../hooks/useChats';
import { useToast } from '../hooks/useToast';
import { Chat, Message } from '../types';
import ChatList from '../components/Chat/ChatList';
import LoadingSpinner from '../components/Common/LoadingSpinner';
import TypingText from '../components/Common/TypingText';

// Lazy load heavy components
const ChatWindow = React.lazy(() => import('../components/Chat/ChatWindow'));
const CreateChatModal = React.lazy(() => import('../components/Chat/CreateChatModal'));
const EditChatModal = React.lazy(() => import('../components/Chat/EditChatModal'));
const ConfirmModal = React.lazy(() => import('../components/Common/ConfirmModal'));
const ToastContainer = React.lazy(() => import('../components/Common/ToastContainer'));

const ChatPage: React.FC = () => {
  const {
    chats,
    currentChatId,
    setCurrentChat,
    setChats,
    updateChat,
    deleteChat,
    addMessage,
    setMessages,
    searchQuery,
    setSearchQuery
  } = useChatStore();

  const { 
    isConnected, 
    sendMessage: sendSocketMessage, 
    toggleRandomMessages 
  } = useSocketChat();

  const {
    chats: apiChats,
    messages: apiMessages,
    isLoading,
    fetchChats,
    createChat: createApiChat,
    fetchMessages,
    sendMessage: sendApiMessage
  } = useChats();

  const { toasts, showToast } = useToast();

  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [selectedChat, setSelectedChat] = useState<Chat | null>(null);
  const [randomMessagesEnabled, setRandomMessagesEnabled] = useState(false);

  // Sync API data with store
  useEffect(() => {
    if (apiChats.length > 0) {
      const formattedChats: Chat[] = apiChats.map(apiChat => ({
        id: apiChat._id,
        firstName: apiChat.participants?.[0] || 'Unknown',
        lastName: apiChat.participants?.[1] || 'User',
        unreadCount: 0,
        isOnline: Math.random() > 0.5,
        lastMessage: apiChat.lastMessage ? {
          id: apiChat.lastMessage._id,
          chatId: apiChat.lastMessage.chatId,
          senderId: apiChat.lastMessage.senderId,
          senderName: apiChat.lastMessage.senderName,
          content: apiChat.lastMessage.content,
          timestamp: new Date(apiChat.lastMessage.timestamp),
          isFromBot: apiChat.lastMessage.senderId !== 'current-user'
        } : undefined,
        lastMessageTime: apiChat.lastMessage ? new Date(apiChat.lastMessage.timestamp) : undefined
      }));
      setChats(formattedChats);
    }
  }, [apiChats, setChats]);

  // Sync messages from API
  useEffect(() => {
    Object.keys(apiMessages).forEach(chatId => {
      const formattedMessages: Message[] = apiMessages[chatId].map(apiMsg => ({
        id: apiMsg._id,
        chatId: apiMsg.chatId,
        senderId: apiMsg.senderId,
        senderName: apiMsg.senderName,
        content: apiMsg.content,
        timestamp: new Date(apiMsg.timestamp),
        isFromBot: apiMsg.senderId !== 'current-user',
        type: apiMsg.type || 'text'
      }));
      setMessages(chatId, formattedMessages);
    });
  }, [apiMessages, setMessages]);

  // Load messages when chat is selected
  useEffect(() => {
    if (currentChatId) {
      fetchMessages(currentChatId);
    }
  }, [currentChatId, fetchMessages]);

  const currentChat = chats.find(chat => chat.id === currentChatId);

  const handleChatSelect = (chat: Chat) => {
    setCurrentChat(chat.id);
  };

  const handleCreateChat = async (firstName: string, lastName: string) => {
    try {
      await createApiChat({
        participants: [firstName, lastName],
        isGroup: false
      });
      setShowCreateModal(false);
      showToast('Chat created successfully!', 'success');
    } catch (error) {
      console.error('Failed to create chat:', error);
    }
  };

  const handleEditChat = (chat: Chat) => {
    setSelectedChat(chat);
    setShowEditModal(true);
  };

  const handleUpdateChat = (firstName: string, lastName: string) => {
    if (selectedChat) {
      updateChat(selectedChat.id, { firstName, lastName });
      setShowEditModal(false);
      setSelectedChat(null);
    }
  };

  const handleDeleteClick = (chatId: string) => {
    const chat = chats.find(c => c.id === chatId);
    setSelectedChat(chat || null);
    setShowDeleteConfirm(true);
  };

  const handleConfirmDelete = () => {
    if (selectedChat) {
      deleteChat(selectedChat.id);
      setShowDeleteConfirm(false);
      setSelectedChat(null);
    }
  };

  const handleSendMessage = async (content: string, type: 'text' | 'image' = 'text', imageUrl?: string) => {
    if (currentChatId && currentChat) {
      console.log('Sending message in chat:', currentChatId, 'Content:', content, 'Type:', type);
      
      try {
        // Send via API
        await sendApiMessage(currentChatId, {
          content,
          type: type || 'text',
          imageUrl
        });

        // Send via socket for real-time
        if (isConnected) {
          sendSocketMessage(currentChatId, content);
        }

        showToast('Message sent!', 'success');
      } catch (error) {
        console.error('Failed to send message:', error);
        // Fallback to local message if API fails
        const userMessage: Message = {
          id: Date.now().toString(),
          chatId: currentChatId,
          senderId: 'current-user',
          senderName: 'You',
          content,
          timestamp: new Date(),
          isFromBot: false,
          type,
          imageUrl
        };
        
        addMessage(userMessage);
        showToast('Message sent locally (API unavailable)', 'warning');
      }
    }
  };

  const handleToggleRandomMessages = () => {
    const newState = !randomMessagesEnabled;
    setRandomMessagesEnabled(newState);
    toggleRandomMessages(newState);
  };

  if (isLoading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="h-screen flex bg-white">
      {/* Sidebar */}
      <div className="w-80 border-r border-gray-200 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-xl font-semibold text-gray-900">Chats</h1>
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
              <span className="text-xs text-gray-500">
                {isConnected ? 'Connected' : 'Disconnected'}
              </span>
            </div>
          </div>
          
          {/* Search */}
          <div className="relative">
            <input
              type="text"
              placeholder="Search or start new chat"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <svg className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          
          {/* Controls */}
          <div className="flex items-center justify-between mt-4">
            <button
              onClick={() => setShowCreateModal(true)}
              className="px-3 py-1.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition-colors"
            >
              New Chat
            </button>
            <button
              onClick={handleToggleRandomMessages}
              className={`px-3 py-1.5 text-sm rounded-lg transition-colors ${
                randomMessagesEnabled
                  ? 'bg-orange-100 text-orange-700 hover:bg-orange-200'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Random: {randomMessagesEnabled ? 'On' : 'Off'}
            </button>
            <button
              onClick={fetchChats}
              className="px-3 py-1.5 bg-gray-100 text-gray-700 text-sm rounded-lg hover:bg-gray-200 transition-colors"
            >
              Refresh
            </button>
          </div>
        </div>

        {/* Chat List */}
        <ChatList
          onChatSelect={handleChatSelect}
          onChatEdit={handleEditChat}
          onChatDelete={handleDeleteClick}
        />
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {currentChat ? (
          <Suspense fallback={<LoadingSpinner />}>
            <ChatWindow
              chat={currentChat}
              onSendMessage={handleSendMessage}
            />
          </Suspense>
        ) : (
          <div className="flex-1 flex items-center justify-center bg-gray-50">
            <div className="text-center">
              <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03 8 9-8s9 3.582 9 8z" />
              </svg>
              <TypingText
                text="Select a chat to start messaging"
                className="text-gray-500 text-lg"
                speed={100}
              />
              <p className="text-gray-400 text-sm mt-2">
                Choose from existing chats or create a new one
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      <Suspense fallback={null}>
        {showCreateModal && (
          <CreateChatModal
            onClose={() => setShowCreateModal(false)}
            onSubmit={handleCreateChat}
          />
        )}
        
        {showEditModal && selectedChat && (
          <EditChatModal
            chat={selectedChat}
            onClose={() => {
              setShowEditModal(false);
              setSelectedChat(null);
            }}
            onSubmit={handleUpdateChat}
          />
        )}
        
        {showDeleteConfirm && selectedChat && (
          <ConfirmModal
            title="Delete Chat"
            message={`Are you sure you want to delete the chat with ${selectedChat.firstName} ${selectedChat.lastName}? This action cannot be undone.`}
            onConfirm={handleConfirmDelete}
            onCancel={() => {
              setShowDeleteConfirm(false);
              setSelectedChat(null);
            }}
          />
        )}

        <ToastContainer toasts={toasts} />
      </Suspense>
    </div>
  );
};

export default ChatPage;
