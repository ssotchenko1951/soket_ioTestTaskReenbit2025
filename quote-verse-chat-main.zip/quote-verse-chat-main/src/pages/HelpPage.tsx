
import React from 'react';
import TypingText from '../components/Common/TypingText';

const HelpPage: React.FC = () => {
  const features = [
    {
      title: 'Real-time Messaging',
      description: 'Send and receive messages instantly with Socket.IO integration',
      icon: '💬'
    },
    {
      title: 'Auto-responses',
      description: 'Get automatic responses with random quotes after 3 seconds',
      icon: '🤖'
    },
    {
      title: 'Chat Management',
      description: 'Create, edit, and delete chats with ease',
      icon: '⚙️'
    },
    {
      title: 'Search Functionality',
      description: 'Find chats and messages quickly with built-in search',
      icon: '🔍'
    },
    {
      title: 'Random Messages',
      description: 'Enable automatic random messages to any chat',
      icon: '🎲'
    },
    {
      title: 'Toast Notifications',
      description: 'Get notified about new messages and system events',
      icon: '🔔'
    }
  ];

  const technicalFeatures = [
    {
      title: 'Socket.IO Integration',
      description: 'Real-time communication with AbortController for connection management',
    },
    {
      title: 'Zustand State Management',
      description: 'Efficient state management with support for mutable and immutable updates',
    },
    {
      title: 'Error Boundaries',
      description: 'Graceful error handling with React Error Boundaries',
    },
    {
      title: 'Lazy Loading',
      description: 'Performance optimized with React.lazy and Suspense',
    },
    {
      title: 'TypeScript',
      description: 'Full type safety throughout the application',
    },
    {
      title: 'Responsive Design',
      description: 'Optimized for all screen sizes and devices',
    }
  ];

  return (
    <div className="max-w-4xl mx-auto px-6 py-12">
      <div className="text-center mb-12">
        <TypingText
          text="ChatApp Help & Documentation"
          className="text-3xl font-bold text-gray-900 mb-4"
          speed={80}
        />
        <p className="text-lg text-gray-600">
          Everything you need to know about using ChatApp
        </p>
      </div>

      {/* Features Section */}
      <section className="mb-12">
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div key={index} className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-md transition-shadow">
              <div className="text-2xl mb-3">{feature.icon}</div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-600 text-sm">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* How to Use Section */}
      <section className="mb-12">
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">How to Use</h2>
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                1. Creating a New Chat
              </h3>
              <p className="text-gray-600">
                Click the "New Chat" button in the sidebar, enter the first and last name of the person you want to chat with, and click "Create".
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                2. Sending Messages
              </h3>
              <p className="text-gray-600">
                Select a chat from the sidebar, type your message in the input field at the bottom, and press Enter or click Send. You'll receive an auto-response after 3 seconds.
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                3. Managing Chats
              </h3>
              <p className="text-gray-600">
                Hover over any chat in the sidebar to see edit and delete options. You can update names or remove chats entirely.
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                4. Search and Random Messages
              </h3>
              <p className="text-gray-600">
                Use the search bar to find specific chats or messages. Toggle "Random Messages" to enable automatic messages to random chats.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Technical Features */}
      <section className="mb-12">
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">Technical Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {technicalFeatures.map((feature, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-600 text-sm">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Configuration Section */}
      <section className="mb-12">
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">Configuration</h2>
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <p className="text-gray-600 mb-4">
            The application is configured to work with both development and production environments. 
            Frontend and backend URLs can be easily configured in the environment settings.
          </p>
          
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-medium text-gray-900 mb-2">Environment URLs:</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Development: Frontend on localhost:5173, Backend on localhost:3001</li>
              <li>• Production: Configurable for external hosting</li>
              <li>• Socket.IO: Automatic connection management with reconnection</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Support Section */}
      <section>
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">Support</h2>
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="text-lg font-medium text-blue-900 mb-2">
            Need Help?
          </h3>
          <p className="text-blue-700 mb-4">
            If you encounter any issues or have questions about using ChatApp, here are some resources:
          </p>
          <ul className="text-blue-700 space-y-2">
            <li>• Check the browser console for error messages</li>
            <li>• Ensure Socket.IO connection is established (green dot in chat sidebar)</li>
            <li>• Verify backend server is running for full functionality</li>
            <li>• Use browser developer tools to inspect network requests</li>
          </ul>
        </div>
      </section>
    </div>
  );
};

export default HelpPage;
