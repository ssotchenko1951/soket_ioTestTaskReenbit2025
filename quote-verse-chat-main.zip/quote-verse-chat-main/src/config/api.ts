
// API configuration for external NestJS backend
interface ApiConfig {
  BASE_URL: string;
  ENDPOINTS: {
    // Authentication
    LOGIN: string;
    REGISTER: string;
    LOGOUT: string;
    REFRESH_TOKEN: string;
    SOCIAL_AUTH: {
      FACEBOOK: string;
      GOOGLE: string;
    };
    // Chats
    CHATS: string;
    CHAT_BY_ID: (id: string) => string;
    CHAT_MESSAGES: (chatId: string) => string;
    SEND_MESSAGE: (chatId: string) => string;
    // Users
    USERS: string;
    USER_PROFILE: string;
  };
}

const development: ApiConfig = {
  BASE_URL: 'http://localhost:3000/api', // NestJS default port
  ENDPOINTS: {
    LOGIN: '/auth/login',
    REGISTER: '/auth/register',
    LOGOUT: '/auth/logout',
    REFRESH_TOKEN: '/auth/refresh',
    SOCIAL_AUTH: {
      FACEBOOK: '/auth/facebook',
      GOOGLE: '/auth/google'
    },
    CHATS: '/chats',
    CHAT_BY_ID: (id: string) => `/chats/${id}`,
    CHAT_MESSAGES: (chatId: string) => `/chats/${chatId}/messages`,
    SEND_MESSAGE: (chatId: string) => `/chats/${chatId}/messages`,
    USERS: '/users',
    USER_PROFILE: '/users/profile'
  }
};

const production: ApiConfig = {
  BASE_URL: 'https://your-nestjs-backend.herokuapp.com/api', // Replace with your production URL
  ENDPOINTS: {
    LOGIN: '/auth/login',
    REGISTER: '/auth/register',
    LOGOUT: '/auth/logout',
    REFRESH_TOKEN: '/auth/refresh',
    SOCIAL_AUTH: {
      FACEBOOK: '/auth/facebook',
      GOOGLE: '/auth/google'
    },
    CHATS: '/chats',
    CHAT_BY_ID: (id: string) => `/chats/${id}`,
    CHAT_MESSAGES: (chatId: string) => `/chats/${chatId}/messages`,
    SEND_MESSAGE: (chatId: string) => `/chats/${chatId}/messages`,
    USERS: '/users',
    USER_PROFILE: '/users/profile'
  }
};

const getApiConfig = (): ApiConfig => {
  const env = import.meta.env.MODE || 'development';
  return env === 'production' ? production : development;
};

export const apiConfig = getApiConfig();
