
// Configuration for frontend and NestJS backend URLs
// This allows easy configuration when deploying to external hosting

interface Environment {
  FRONTEND_URL: string;
  BACKEND_URL: string;
  SOCKET_URL: string;
  API_BASE_URL: string;
}

const development: Environment = {
  FRONTEND_URL: 'http://localhost:5173',
  BACKEND_URL: 'http://localhost:3000', // NestJS default port
  SOCKET_URL: 'http://localhost:3000', // Socket.io on same port as NestJS
  API_BASE_URL: 'http://localhost:3000/api'
};

const production: Environment = {
  FRONTEND_URL: 'https://your-frontend-domain.com',
  BACKEND_URL: 'https://your-nestjs-backend.herokuapp.com', 
  SOCKET_URL: 'https://your-nestjs-backend.herokuapp.com',
  API_BASE_URL: 'https://your-nestjs-backend.herokuapp.com/api'
};

const staging: Environment = {
  FRONTEND_URL: 'https://staging-frontend.com',
  BACKEND_URL: 'https://staging-nestjs-backend.com',
  SOCKET_URL: 'https://staging-nestjs-backend.com', 
  API_BASE_URL: 'https://staging-nestjs-backend.com/api'
};

const getEnvironment = (): Environment => {
  const env = import.meta.env.MODE || 'development';
  
  switch (env) {
    case 'production':
      return production;
    case 'staging':
      return staging;
    default:
      return development;
  }
};

export const config = getEnvironment();

export const API_ENDPOINTS = {
  CHATS: `${config.API_BASE_URL}/chats`,
  MESSAGES: `${config.API_BASE_URL}/messages`,
  AUTH: `${config.API_BASE_URL}/auth`,
  USERS: `${config.API_BASE_URL}/users`
};
