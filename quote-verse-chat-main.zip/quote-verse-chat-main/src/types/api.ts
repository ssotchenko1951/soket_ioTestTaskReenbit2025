
// API types for MongoDB Atlas backend integration

export interface ApiUser {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  avatar?: string;
  isOnline?: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface ApiChat {
  _id: string;
  participants: ApiUser[];
  lastMessage?: ApiMessage;
  unreadCount: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface ApiMessage {
  _id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  content: string;
  type: 'text' | 'image';
  imageUrl?: string;
  timestamp: Date;
  isRead: boolean;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
}

export interface AuthResponse {
  user: ApiUser;
  accessToken: string;
  refreshToken: string;
}

export interface CreateChatRequest {
  participantId: string;
}

export interface SendMessageRequest {
  content: string;
  type: 'text' | 'image';
  imageUrl?: string;
}

export interface ApiError {
  message: string;
  code: string;
  status: number;
}

// Social auth types
export interface SocialAuthRequest {
  provider: 'facebook' | 'google';
  accessToken: string;
}
