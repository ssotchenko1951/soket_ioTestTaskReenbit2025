
export interface User {
  id: string;
  firstName: string;
  lastName: string;
  avatar?: string;
  email?: string;
  isOnline?: boolean;
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  content: string;
  timestamp: Date;
  isFromBot?: boolean;
  isRead?: boolean;
  type?: 'text' | 'image';
  imageUrl?: string;
}

export interface Chat {
  id: string;
  firstName: string;
  lastName: string;
  avatar?: string;
  lastMessage?: Message;
  lastMessageTime?: Date;
  unreadCount: number;
  isOnline?: boolean;
}

export interface SocketEvents {
  message: (data: Message) => void;
  'new-chat': (data: Chat) => void;
  'chat-updated': (data: Chat) => void;
  'chat-deleted': (chatId: string) => void;
  'user-typing': (data: { chatId: string; userName: string }) => void;
  'random-message': (data: Message) => void;
}

export interface ChatStore {
  chats: Chat[];
  messages: Record<string, Message[]>;
  currentChatId: string | null;
  isConnected: boolean;
  isLoading: boolean;
  searchQuery: string;
  
  // Actions
  setChats: (chats: Chat[]) => void;
  addChat: (chat: Chat) => void;
  updateChat: (chatId: string, updates: Partial<Chat>) => void;
  deleteChat: (chatId: string) => void;
  setCurrentChat: (chatId: string | null) => void;
  addMessage: (message: Message) => void;
  updateMessage: (messageId: string, updates: Partial<Message>) => void;
  setMessages: (chatId: string, messages: Message[]) => void;
  setConnected: (connected: boolean) => void;
  setLoading: (loading: boolean) => void;
  setSearchQuery: (query: string) => void;
  getFilteredChats: () => Chat[];
}

export type ToastType = 'success' | 'error' | 'info' | 'warning';

export interface Toast {
  id: string;
  type: ToastType;
  message: string;
  duration?: number;
}
