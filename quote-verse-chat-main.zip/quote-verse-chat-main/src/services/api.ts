
import { apiConfig } from '../config/api';
import { 
  ApiUser, 
  ApiChat, 
  ApiMessage, 
  LoginRequest, 
  RegisterRequest, 
  AuthResponse,
  CreateChatRequest,
  SendMessageRequest,
  SocialAuthRequest,
  ApiError
} from '../types/api';

class ApiClient {
  private baseUrl: string;
  private token: string | null = null;

  constructor() {
    this.baseUrl = apiConfig.BASE_URL;
    this.token = localStorage.getItem('accessToken');
  }

  setToken(token: string) {
    this.token = token;
    localStorage.setItem('accessToken', token);
  }

  clearToken() {
    this.token = null;
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`;
    
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>),
    };

    if (this.token) {
      headers.Authorization = `Bearer ${this.token}`;
    }

    const response = await fetch(url, {
      ...options,
      headers,
    });

    if (!response.ok) {
      const errorData: ApiError = await response.json();
      throw new Error(errorData.message || 'API request failed');
    }

    return response.json();
  }

  // Authentication methods
  async login(credentials: LoginRequest): Promise<AuthResponse> {
    const response = await this.request<AuthResponse>(
      apiConfig.ENDPOINTS.LOGIN,
      {
        method: 'POST',
        body: JSON.stringify(credentials),
      }
    );
    
    this.setToken(response.accessToken);
    localStorage.setItem('refreshToken', response.refreshToken);
    return response;
  }

  async register(userData: RegisterRequest): Promise<AuthResponse> {
    const response = await this.request<AuthResponse>(
      apiConfig.ENDPOINTS.REGISTER,
      {
        method: 'POST',
        body: JSON.stringify(userData),
      }
    );
    
    this.setToken(response.accessToken);
    localStorage.setItem('refreshToken', response.refreshToken);
    return response;
  }

  async socialAuth(socialData: SocialAuthRequest): Promise<AuthResponse> {
    const endpoint = socialData.provider === 'facebook' 
      ? apiConfig.ENDPOINTS.SOCIAL_AUTH.FACEBOOK 
      : apiConfig.ENDPOINTS.SOCIAL_AUTH.GOOGLE;
    
    const response = await this.request<AuthResponse>(endpoint, {
      method: 'POST',
      body: JSON.stringify(socialData),
    });
    
    this.setToken(response.accessToken);
    localStorage.setItem('refreshToken', response.refreshToken);
    return response;
  }

  async logout(): Promise<void> {
    await this.request(apiConfig.ENDPOINTS.LOGOUT, {
      method: 'POST',
    });
    this.clearToken();
  }

  // Chat methods
  async getChats(): Promise<ApiChat[]> {
    return this.request<ApiChat[]>(apiConfig.ENDPOINTS.CHATS);
  }

  async createChat(chatData: CreateChatRequest): Promise<ApiChat> {
    return this.request<ApiChat>(apiConfig.ENDPOINTS.CHATS, {
      method: 'POST',
      body: JSON.stringify(chatData),
    });
  }

  async getChatMessages(chatId: string): Promise<ApiMessage[]> {
    return this.request<ApiMessage[]>(
      apiConfig.ENDPOINTS.CHAT_MESSAGES(chatId)
    );
  }

  async sendMessage(chatId: string, messageData: SendMessageRequest): Promise<ApiMessage> {
    return this.request<ApiMessage>(
      apiConfig.ENDPOINTS.SEND_MESSAGE(chatId),
      {
        method: 'POST',
        body: JSON.stringify(messageData),
      }
    );
  }

  // User methods
  async getUserProfile(): Promise<ApiUser> {
    return this.request<ApiUser>(apiConfig.ENDPOINTS.USER_PROFILE);
  }

  async getUsers(): Promise<ApiUser[]> {
    return this.request<ApiUser[]>(apiConfig.ENDPOINTS.USERS);
  }
}

export const apiClient = new ApiClient();
