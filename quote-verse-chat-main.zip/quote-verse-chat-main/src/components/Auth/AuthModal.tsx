
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import LoginForm from './LoginForm';
import RegisterForm from './RegisterForm';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const [isLoginMode, setIsLoginMode] = useState(true);

  const handleSuccess = () => {
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {isLoginMode ? 'Login to your account' : 'Create new account'}
          </DialogTitle>
        </DialogHeader>
        
        {isLoginMode ? (
          <LoginForm
            onSuccess={handleSuccess}
            onSwitchToRegister={() => setIsLoginMode(false)}
          />
        ) : (
          <RegisterForm
            onSuccess={handleSuccess}
            onSwitchToLogin={() => setIsLoginMode(true)}
          />
        )}
      </DialogContent>
    </Dialog>
  );
};

export default AuthModal;
