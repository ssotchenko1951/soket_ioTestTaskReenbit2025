
import React, { Suspense } from 'react';
import { ErrorBoundary } from 'react-error-boundary';
import Header from './Header';
import Footer from './Footer';
import LoadingSpinner from '../Common/LoadingSpinner';
import ErrorFallback from '../Common/ErrorFallback';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="flex-1">
        <ErrorBoundary
          FallbackComponent={ErrorFallback}
          onError={(error, errorInfo) => {
            console.error('Error caught by boundary:', error, errorInfo);
          }}
        >
          <Suspense fallback={<LoadingSpinner />}>
            {children}
          </Suspense>
        </ErrorBoundary>
      </main>
      
      <Footer />
    </div>
  );
};

export default Layout;
