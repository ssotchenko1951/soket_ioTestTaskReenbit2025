
import React from 'react';
import { Smile } from 'lucide-react';

interface EmojiPickerProps {
  onEmojiSelect: (emoji: string) => void;
  isOpen: boolean;
  onToggle: () => void;
}

const EMOJIS = [
  '😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇',
  '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚',
  '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓', '😎', '🤩',
  '🥳', '😏', '😒', '😞', '😔', '😟', '😕', '🙁', '☹️', '😣',
  '😖', '😫', '😩', '🥺', '😢', '😭', '😤', '😠', '😡', '🤬',
  '🤯', '😳', '🥵', '🥶', '😱', '😨', '😰', '😥', '😓', '🤗',
  '🤔', '🤭', '🤫', '🤥', '😶', '😐', '😑', '😬', '🙄', '😯',
  '😦', '😧', '😮', '😲', '🥱', '😴', '🤤', '😪', '😵', '🤐',
  '🥴', '🤢', '🤮', '🤧', '😷', '🤒', '🤕', '🤑', '🤠', '😈',
  '👍', '👎', '👌', '✌️', '🤞', '🤟', '🤘', '🤙', '👈', '👉',
  '👆', '🖕', '👇', '☝️', '👋', '🤚', '🖐️', '✋', '🖖', '👏',
  '🙌', '🤲', '🤝', '🙏', '❤️', '🧡', '💛', '💚', '💙', '💜'
];

const EmojiPicker: React.FC<EmojiPickerProps> = ({ onEmojiSelect, isOpen, onToggle }) => {
  if (!isOpen) {
    return (
      <button
        type="button"
        onClick={onToggle}
        className="p-2 text-gray-400 hover:text-gray-600 transition-all duration-200 hover:scale-110"
        title="Add emoji"
      >
        <Smile className="w-5 h-5" />
      </button>
    );
  }

  return (
    <div className="relative">
      <button
        type="button"
        onClick={onToggle}
        className="p-2 text-blue-600 hover:text-blue-700 transition-all duration-200 hover:scale-110"
        title="Close emoji picker"
      >
        <Smile className="w-5 h-5" />
      </button>
      
      <div className="absolute bottom-12 left-0 bg-white border border-gray-200 rounded-lg shadow-lg p-4 w-80 max-h-64 overflow-y-auto z-50 animate-scale-in">
        <div className="grid grid-cols-8 gap-2">
          {EMOJIS.map((emoji, index) => (
            <button
              key={index}
              type="button"
              onClick={() => {
                onEmojiSelect(emoji);
                onToggle();
              }}
              className="text-xl hover:bg-gray-100 rounded p-1 transition-all duration-200 hover:scale-125 animate-fade-in"
              style={{ animationDelay: `${index * 10}ms` }}
              title={emoji}
            >
              {emoji}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default EmojiPicker;
