
import React, { useState } from 'react';
import { Chat } from '../../types';
import MessageList from './MessageList';
import MessageInput from './MessageInput';
import CallModal from './CallModal';
import { Phone, Video } from 'lucide-react';

interface ChatWindowProps {
  chat: Chat;
  onSendMessage: (content: string, type?: 'text' | 'image', imageUrl?: string) => void;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ chat, onSendMessage }) => {
  const [showCallModal, setShowCallModal] = useState(false);
  const [isVideoCall, setIsVideoCall] = useState(false);

  const handleAudioCall = () => {
    setIsVideoCall(false);
    setShowCallModal(true);
  };

  const handleVideoCall = () => {
    setIsVideoCall(true);
    setShowCallModal(true);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Chat Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-white">
        <div className="flex items-center">
          <div className="relative mr-3">
            <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center">
              <span className="text-sm font-medium text-gray-600">
                {chat.firstName[0]}{chat.lastName[0]}
              </span>
            </div>
            {chat.isOnline && (
              <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
            )}
          </div>
          <div>
            <h2 className="text-lg font-semibold text-gray-900">
              {chat.firstName} {chat.lastName}
            </h2>
            <p className="text-sm text-gray-500">
              {chat.isOnline ? 'Online' : 'Offline'}
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <button 
            onClick={handleAudioCall}
            className="p-2 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-full transition-colors"
            title="Audio Call"
          >
            <Phone className="w-5 h-5" />
          </button>
          <button 
            onClick={handleVideoCall}
            className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors"
            title="Video Call"
          >
            <Video className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Messages */}
      <MessageList chatId={chat.id} />

      {/* Message Input */}
      <MessageInput onSendMessage={onSendMessage} />

      {/* Call Modal */}
      {showCallModal && (
        <CallModal
          isOpen={showCallModal}
          onClose={() => setShowCallModal(false)}
          contactName={`${chat.firstName} ${chat.lastName}`}
          isVideoCall={isVideoCall}
        />
      )}
    </div>
  );
};

export default ChatWindow;
