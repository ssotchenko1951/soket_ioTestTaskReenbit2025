
import React from 'react';
import { Chat } from '../../types';

interface ChatItemProps {
  chat: Chat;
  isSelected: boolean;
  onClick: () => void;
  onEdit: () => void;
  onDelete: () => void;
}

const ChatItem: React.FC<ChatItemProps> = ({
  chat,
  isSelected,
  onClick,
  onEdit,
  onDelete
}) => {
  const formatTime = (date: Date | undefined) => {
    if (!date) return '';
    const now = new Date();
    const messageDate = new Date(date);
    const diffInDays = Math.floor((now.getTime() - messageDate.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffInDays === 0) {
      return messageDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diffInDays < 7) {
      return messageDate.toLocaleDateString([], { month: 'short', day: 'numeric' });
    } else {
      return messageDate.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
    }
  };

  return (
    <div
      className={`group flex items-center p-4 border-b border-gray-100 hover:bg-gray-50 cursor-pointer transition-all duration-200 hover:scale-[1.02] ${
        isSelected ? 'bg-blue-50 border-l-4 border-l-blue-500 animate-fade-in' : ''
      }`}
      onClick={onClick}
    >
      <div className="relative flex-shrink-0 mr-3">
        <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center transition-transform duration-200 group-hover:scale-110">
          <span className="text-sm font-medium text-gray-600">
            {chat.firstName[0]}{chat.lastName[0]}
          </span>
        </div>
        {chat.isOnline && (
          <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 rounded-full border-2 border-white animate-pulse"></div>
        )}
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-1">
          <h3 className="text-sm font-medium text-gray-900 truncate transition-colors duration-200 group-hover:text-blue-600">
            {chat.firstName} {chat.lastName}
          </h3>
          <div className="flex items-center space-x-2">
            <span className="text-xs text-gray-500 transition-opacity duration-200 group-hover:opacity-70">
              {formatTime(chat.lastMessageTime)}
            </span>
            {chat.unreadCount > 0 && (
              <span className="bg-blue-500 text-white text-xs rounded-full px-2 py-0.5 min-w-[20px] text-center animate-pulse">
                {chat.unreadCount}
              </span>
            )}
          </div>
        </div>
        <p className="text-sm text-gray-600 truncate transition-colors duration-200 group-hover:text-gray-800">
          {chat.lastMessage?.content || 'No messages yet'}
        </p>
      </div>
      
      <div className="flex items-center space-x-1 ml-2 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-x-2 group-hover:translate-x-0">
        <button
          onClick={(e) => {
            e.stopPropagation();
            onEdit();
          }}
          className="p-1 text-gray-400 hover:text-gray-600 transition-all duration-200 hover:scale-110"
          title="Edit chat"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
          </svg>
        </button>
        <button
          onClick={(e) => {
            e.stopPropagation();
            onDelete();
          }}
          className="p-1 text-gray-400 hover:text-red-600 transition-all duration-200 hover:scale-110"
          title="Delete chat"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
          </svg>
        </button>
      </div>
    </div>
  );
};

export default ChatItem;
