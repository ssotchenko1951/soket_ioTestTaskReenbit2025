
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Button } from '../ui/button';
import { useWebRTC } from '../../hooks/useWebRTC';
import { Mic, MicOff, Video, VideoOff, Phone, PhoneOff } from 'lucide-react';

interface CallModalProps {
  isOpen: boolean;
  onClose: () => void;
  contactName: string;
  isVideoCall: boolean;
}

const CallModal: React.FC<CallModalProps> = ({
  isOpen,
  onClose,
  contactName,
  isVideoCall
}) => {
  const {
    isCallActive,
    isAudioEnabled,
    isVideoEnabled,
    connectionState,
    localVideoRef,
    remoteVideoRef,
    startCall,
    endCall,
    toggleAudio,
    toggleVideo
  } = useWebRTC({
    onConnectionStateChange: (state) => {
      if (state === 'disconnected' || state === 'failed') {
        onClose();
      }
    }
  });

  const handleStartCall = () => {
    startCall(isVideoCall);
  };

  const handleEndCall = () => {
    endCall();
    onClose();
  };

  const getConnectionText = () => {
    switch (connectionState) {
      case 'connecting':
        return 'Connecting...';
      case 'connected':
        return 'Connected';
      case 'disconnected':
        return 'Disconnected';
      case 'failed':
        return 'Connection failed';
      default:
        return isCallActive ? 'Starting call...' : 'Ready to call';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl h-[600px]">
        <DialogHeader>
          <DialogTitle>
            {isVideoCall ? 'Video Call' : 'Audio Call'} with {contactName}
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex flex-col space-y-4">
          {/* Connection Status */}
          <div className="text-center p-2 bg-gray-100 rounded-lg">
            <span className="text-sm font-medium">{getConnectionText()}</span>
          </div>

          {/* Video Area */}
          {isVideoCall && (
            <div className="flex-1 relative bg-gray-900 rounded-lg overflow-hidden">
              {/* Remote Video */}
              <video
                ref={remoteVideoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />
              
              {/* Local Video - Picture in Picture */}
              <div className="absolute top-4 right-4 w-32 h-24 bg-gray-800 rounded-lg overflow-hidden border-2 border-white">
                <video
                  ref={localVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
              </div>

              {/* No video placeholder */}
              {!isCallActive && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center text-white">
                    <div className="w-20 h-20 bg-gray-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <span className="text-2xl font-semibold">
                        {contactName.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <p className="text-lg font-medium">{contactName}</p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Audio Only Mode */}
          {!isVideoCall && (
            <div className="flex-1 flex items-center justify-center bg-gray-100 rounded-lg">
              <div className="text-center">
                <div className="w-24 h-24 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl font-semibold text-white">
                    {contactName.split(' ').map(n => n[0]).join('')}
                  </span>
                </div>
                <p className="text-xl font-medium text-gray-900">{contactName}</p>
                <p className="text-gray-600 mt-2">{getConnectionText()}</p>
              </div>
            </div>
          )}

          {/* Call Controls */}
          <div className="flex justify-center space-x-4 p-4 bg-gray-50 rounded-lg">
            {!isCallActive ? (
              <Button
                onClick={handleStartCall}
                className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-full"
              >
                <Phone className="w-5 h-5 mr-2" />
                Start {isVideoCall ? 'Video' : 'Audio'} Call
              </Button>
            ) : (
              <>
                {/* Audio Toggle */}
                <Button
                  onClick={toggleAudio}
                  variant={isAudioEnabled ? "outline" : "destructive"}
                  size="lg"
                  className="rounded-full"
                >
                  {isAudioEnabled ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
                </Button>

                {/* Video Toggle (only for video calls) */}
                {isVideoCall && (
                  <Button
                    onClick={toggleVideo}
                    variant={isVideoEnabled ? "outline" : "destructive"}
                    size="lg"
                    className="rounded-full"
                  >
                    {isVideoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
                  </Button>
                )}

                {/* End Call */}
                <Button
                  onClick={handleEndCall}
                  variant="destructive"
                  size="lg"
                  className="rounded-full bg-red-600 hover:bg-red-700"
                >
                  <PhoneOff className="w-5 h-5" />
                </Button>
              </>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CallModal;
