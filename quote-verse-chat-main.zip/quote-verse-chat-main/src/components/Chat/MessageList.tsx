
import React from 'react';
import { useChatStore } from '../../store/chatStore';
import { Message } from '../../types';
import LazyLoad from '../Common/LazyLoad';
import { Skeleton } from '../ui/skeleton';

interface MessageListProps {
  chatId: string;
}

const MessageList: React.FC<MessageListProps> = ({ chatId }) => {
  const { messages, isLoading } = useChatStore();
  const chatMessages = messages[chatId] || [];

  if (isLoading) {
    return (
      <div className="flex-1 overflow-y-auto p-6 bg-gray-50">
        <div className="space-y-4">
          {[...Array(5)].map((_, index) => (
            <MessageSkeleton key={index} isOwnMessage={index % 2 === 0} />
          ))}
        </div>
      </div>
    );
  }

  if (chatMessages.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center text-gray-500 bg-gray-50">
        <div className="text-center animate-fade-in">
          <svg className="w-12 h-12 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
          </svg>
          <p>No messages yet</p>
          <p className="text-sm text-gray-400 mt-1">Start the conversation!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto p-6 bg-gray-50">
      <div className="space-y-4">
        {chatMessages.map((message, index) => (
          <LazyLoad key={message.id}>
            <div 
              className="animate-fade-in"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <MessageItem message={message} />
            </div>
          </LazyLoad>
        ))}
      </div>
    </div>
  );
};

interface MessageItemProps {
  message: Message;
}

const MessageItem: React.FC<MessageItemProps> = ({ message }) => {
  const isOwnMessage = message.senderId === 'current-user';
  
  return (
    <div className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'} group`}>
      <div
        className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg transition-all duration-200 hover:scale-105 ${
          isOwnMessage
            ? 'bg-blue-600 text-white hover:bg-blue-700'
            : 'bg-white text-gray-900 border border-gray-200 hover:shadow-md'
        }`}
      >
        {message.type === 'image' && message.imageUrl ? (
          <div>
            <img
              src={message.imageUrl}
              alt="Shared image"
              className="max-w-full h-auto rounded-lg mb-2 transition-transform duration-300 hover:scale-110"
              style={{ maxHeight: '200px' }}
            />
            <p className="text-sm">{message.content}</p>
          </div>
        ) : (
          <p className="text-sm whitespace-pre-wrap">{message.content}</p>
        )}
        <p
          className={`text-xs mt-1 transition-opacity duration-200 ${
            isOwnMessage ? 'text-blue-100' : 'text-gray-500'
          } opacity-70 group-hover:opacity-100`}
        >
          {new Date(message.timestamp).toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit'
          })}
        </p>
      </div>
    </div>
  );
};

interface MessageSkeletonProps {
  isOwnMessage: boolean;
}

const MessageSkeleton: React.FC<MessageSkeletonProps> = ({ isOwnMessage }) => {
  return (
    <div className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'} animate-pulse`}>
      <div className="max-w-xs lg:max-w-md">
        <Skeleton className={`h-16 ${isOwnMessage ? 'bg-blue-100' : 'bg-gray-200'} rounded-lg mb-1`} />
        <Skeleton className="h-3 w-16 bg-gray-100" />
      </div>
    </div>
  );
};

export default MessageList;
