
import { useEffect, useRef, useState, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';
import { config } from '../config/environment';
import { useChatStore } from '../store/chatStore';
import { Message, SocketEvents } from '../types';
import { useToast } from './useToast';

interface UseSocketChatOptions {
  autoConnect?: boolean;
  reconnection?: boolean;
  reconnectionAttempts?: number;
  reconnectionDelay?: number;
}

interface UseSocketChatReturn {
  socket: Socket | null;
  isConnected: boolean;
  connect: () => void;
  disconnect: () => void;
  sendMessage: (chatId: string, content: string) => void;
  joinChat: (chatId: string) => void;
  leaveChat: (chatId: string) => void;
  toggleRandomMessages: (enabled: boolean) => void;
}

export const useSocketChat = (
  options: UseSocketChatOptions = {}
): UseSocketChatReturn => {
  const {
    autoConnect = true,
    reconnection = true,
    reconnectionAttempts = 5,
    reconnectionDelay = 1000,
  } = options;

  const [socket, setSocket] = useState<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);
  
  const { addMessage, setConnected, currentChatId, addChat, updateChat } = useChatStore();
  const { showToast } = useToast();

  const connect = useCallback(() => {
    if (socket?.connected) return;

    // Create new AbortController for this connection
    abortControllerRef.current = new AbortController();
    
    const newSocket = io(config.SOCKET_URL, {
      reconnection,
      reconnectionAttempts,
      reconnectionDelay,
      transports: ['websocket', 'polling'],
      timeout: 20000,
      forceNew: true
    });

    // Connection event handlers
    newSocket.on('connect', () => {
      console.log('Connected to socket server');
      setIsConnected(true);
      setConnected(true);
      showToast('Connected to chat server', 'success');
    });

    newSocket.on('disconnect', (reason) => {
      console.log('Disconnected from socket server:', reason);
      setIsConnected(false);
      setConnected(false);
      if (reason !== 'io client disconnect') {
        showToast('Disconnected from chat server', 'warning');
      }
    });

    newSocket.on('connect_error', (error) => {
      console.error('Socket connection error:', error);
      setIsConnected(false);
      setConnected(false);
      showToast('Failed to connect to chat server (using local mode)', 'warning');
    });

    // Chat event handlers with better error handling
    newSocket.on('message', (message: Message) => {
      console.log('Received message via socket:', message);
      try {
        addMessage(message);
        if (message.chatId !== currentChatId && message.isFromBot) {
          showToast(`New message from ${message.senderName}`, 'info');
        }
      } catch (error) {
        console.error('Error handling received message:', error);
      }
    });

    newSocket.on('new-chat', (chat) => {
      console.log('New chat received via socket:', chat);
      try {
        const formattedChat = {
          id: chat._id || chat.id,
          firstName: chat.participants?.[0] || 'Unknown',
          lastName: chat.participants?.[1] || 'User',
          unreadCount: 0,
          isOnline: Math.random() > 0.5
        };
        addChat(formattedChat);
        showToast(`New chat created: ${formattedChat.firstName} ${formattedChat.lastName}`, 'success');
      } catch (error) {
        console.error('Error handling new chat:', error);
      }
    });

    newSocket.on('chat-updated', (chat) => {
      console.log('Chat updated via socket:', chat);
      try {
        updateChat(chat._id || chat.id, {
          firstName: chat.participants?.[0] || 'Unknown',
          lastName: chat.participants?.[1] || 'User'
        });
      } catch (error) {
        console.error('Error handling chat update:', error);
      }
    });

    newSocket.on('random-message', (message: Message) => {
      console.log('Random message received via socket:', message);
      try {
        addMessage(message);
        showToast(`Random message received in ${message.senderName}'s chat`, 'info');
      } catch (error) {
        console.error('Error handling random message:', error);
      }
    });

    newSocket.on('user-typing', ({ chatId, userName }) => {
      if (chatId === currentChatId) {
        console.log(`${userName} is typing...`);
        // You can add typing indicator logic here
      }
    });

    // Handle abort signal
    abortControllerRef.current.signal.addEventListener('abort', () => {
      newSocket.disconnect();
    });

    setSocket(newSocket);
  }, [socket, addMessage, setConnected, currentChatId, addChat, updateChat, showToast, reconnection, reconnectionAttempts, reconnectionDelay]);

  const disconnect = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    
    if (socket) {
      socket.disconnect();
      setSocket(null);
      setIsConnected(false);
      setConnected(false);
      showToast('Disconnected from chat server', 'info');
    }
  }, [socket, setConnected, showToast]);

  const sendMessage = useCallback((chatId: string, content: string) => {
    if (!socket?.connected) {
      console.warn('Socket not connected, message not sent via socket');
      return;
    }

    const message: Omit<Message, 'id' | 'timestamp'> = {
      chatId,
      senderId: 'current-user',
      senderName: 'You',
      content,
      isFromBot: false,
      type: 'text'
    };

    console.log('Sending message via socket:', message);
    socket.emit('send-message', message);
  }, [socket]);

  const joinChat = useCallback((chatId: string) => {
    if (socket?.connected) {
      console.log('Joining chat via socket:', chatId);
      socket.emit('join-chat', chatId);
    }
  }, [socket]);

  const leaveChat = useCallback((chatId: string) => {
    if (socket?.connected) {
      console.log('Leaving chat via socket:', chatId);
      socket.emit('leave-chat', chatId);
    }
  }, [socket]);

  const toggleRandomMessages = useCallback((enabled: boolean) => {
    if (socket?.connected) {
      console.log('Toggling random messages via socket:', enabled);
      socket.emit('toggle-random-messages', enabled);
      showToast(
        `Random messages ${enabled ? 'enabled' : 'disabled'}`,
        'info'
      );
    }
  }, [socket, showToast]);

  // Auto-connect on mount
  useEffect(() => {
    if (autoConnect) {
      connect();
    }

    // Cleanup on unmount
    return () => {
      disconnect();
    };
  }, [autoConnect]);

  // Join current chat when it changes
  useEffect(() => {
    if (currentChatId && socket?.connected) {
      joinChat(currentChatId);
    }
  }, [currentChatId, socket, joinChat]);

  return {
    socket,
    isConnected,
    connect,
    disconnect,
    sendMessage,
    joinChat,
    leaveChat,
    toggleRandomMessages,
  };
};
