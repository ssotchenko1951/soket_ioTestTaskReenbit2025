
import { useState, useEffect, useCallback } from 'react';
import { apiClient } from '../services/api';
import { ApiUser, LoginRequest, RegisterRequest, SocialAuthRequest } from '../types/api';
import { useToast } from './useToast';

interface UseAuthReturn {
  user: ApiUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (credentials: LoginRequest) => Promise<void>;
  register: (userData: RegisterRequest) => Promise<void>;
  socialLogin: (socialData: SocialAuthRequest) => Promise<void>;
  logout: () => Promise<void>;
  checkAuthStatus: () => Promise<void>;
}

export const useAuth = (): UseAuthReturn => {
  const [user, setUser] = useState<ApiUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { showToast } = useToast();

  const checkAuthStatus = useCallback(async () => {
    try {
      const token = localStorage.getItem('accessToken');
      if (!token) {
        setIsLoading(false);
        return;
      }

      const userProfile = await apiClient.getUserProfile();
      setUser(userProfile);
    } catch (error) {
      console.error('Auth check failed:', error);
      apiClient.clearToken();
    } finally {
      setIsLoading(false);
    }
  }, []);

  const login = useCallback(async (credentials: LoginRequest) => {
    try {
      setIsLoading(true);
      const response = await apiClient.login(credentials);
      setUser(response.user);
      showToast('Successfully logged in!', 'success');
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Login failed';
      showToast(message, 'error');
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, [showToast]);

  const register = useCallback(async (userData: RegisterRequest) => {
    try {
      setIsLoading(true);
      const response = await apiClient.register(userData);
      setUser(response.user);
      showToast('Account created successfully!', 'success');
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Registration failed';
      showToast(message, 'error');
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, [showToast]);

  const socialLogin = useCallback(async (socialData: SocialAuthRequest) => {
    try {
      setIsLoading(true);
      const response = await apiClient.socialAuth(socialData);
      setUser(response.user);
      showToast(`Successfully logged in with ${socialData.provider}!`, 'success');
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Social login failed';
      showToast(message, 'error');
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, [showToast]);

  const logout = useCallback(async () => {
    try {
      await apiClient.logout();
      setUser(null);
      showToast('Successfully logged out!', 'info');
    } catch (error) {
      console.error('Logout error:', error);
      // Force logout even if API call fails
      apiClient.clearToken();
      setUser(null);
    }
  }, [showToast]);

  useEffect(() => {
    checkAuthStatus();
  }, [checkAuthStatus]);

  return {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    register,
    socialLogin,
    logout,
    checkAuthStatus,
  };
};
