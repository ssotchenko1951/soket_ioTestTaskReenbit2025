
import { useState, useEffect, useCallback } from 'react';
import { apiClient } from '../services/api';
import { ApiChat, ApiMessage, CreateChatRequest, SendMessageRequest } from '../types/api';
import { useToast } from './useToast';

interface UseChatsReturn {
  chats: ApiChat[];
  messages: Record<string, ApiMessage[]>;
  isLoading: boolean;
  fetchChats: () => Promise<void>;
  createChat: (chatData: CreateChatRequest) => Promise<void>;
  fetchMessages: (chatId: string) => Promise<void>;
  sendMessage: (chatId: string, messageData: SendMessageRequest) => Promise<void>;
}

export const useChats = (): UseChatsReturn => {
  const [chats, setChats] = useState<ApiChat[]>([]);
  const [messages, setMessages] = useState<Record<string, ApiMessage[]>>({});
  const [isLoading, setIsLoading] = useState(false);
  const { showToast } = useToast();

  const fetchChats = useCallback(async () => {
    try {
      setIsLoading(true);
      const chatsData = await apiClient.getChats();
      setChats(chatsData);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to fetch chats';
      showToast(message, 'error');
    } finally {
      setIsLoading(false);
    }
  }, [showToast]);

  const createChat = useCallback(async (chatData: CreateChatRequest) => {
    try {
      const newChat = await apiClient.createChat(chatData);
      setChats(prev => [newChat, ...prev]);
      showToast('Chat created successfully!', 'success');
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to create chat';
      showToast(message, 'error');
      throw error;
    }
  }, [showToast]);

  const fetchMessages = useCallback(async (chatId: string) => {
    try {
      const messagesData = await apiClient.getChatMessages(chatId);
      setMessages(prev => ({
        ...prev,
        [chatId]: messagesData
      }));
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to fetch messages';
      showToast(message, 'error');
    }
  }, [showToast]);

  const sendMessage = useCallback(async (chatId: string, messageData: SendMessageRequest) => {
    try {
      const newMessage = await apiClient.sendMessage(chatId, messageData);
      
      // Update messages in state
      setMessages(prev => ({
        ...prev,
        [chatId]: [...(prev[chatId] || []), newMessage]
      }));

      // Update chat's last message
      setChats(prev => prev.map(chat => 
        chat._id === chatId 
          ? { ...chat, lastMessage: newMessage }
          : chat
      ));
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to send message';
      showToast(message, 'error');
      throw error;
    }
  }, [showToast]);

  useEffect(() => {
    fetchChats();
  }, [fetchChats]);

  return {
    chats,
    messages,
    isLoading,
    fetchChats,
    createChat,
    fetchMessages,
    sendMessage,
  };
};
